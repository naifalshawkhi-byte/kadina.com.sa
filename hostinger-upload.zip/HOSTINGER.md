# نشر على Hostinger — دليل سريع

هذا التطبيق **Next.js + Node.js**. يحتاج خطة **Business** أو **Cloud** مع **Node.js Web Apps**.

---

## قبل الرفع (على جهازك)

```bash
npm run prepare:hostinger
```

سيُنشئ:
- **`hostinger-upload.zip`** — الملف الذي ترفعه إلى Hostinger
- **`HOSTINGER-ENV.txt`** — المتغيرات البيئية (احفظه ولا ترفعه علناً)

الملف المضغوط يتضمن **`data/db.json`** (قاعدة بيانات العيادة) إن وُجدت.

---

## خطوات Hostinger (hPanel)

### 1. إضافة الموقع
1. **Websites** → **Add Website**
2. اختر **Node.js Apps**
3. **Upload your files** → ارفع `hostinger-upload.zip`

### 2. إعدادات البناء (Build settings)

| الحقل | القيمة |
|-------|--------|
| Framework | Next.js |
| Node.js | **20** |
| Install command | `npm ci` |
| Build command | `npm run build` |
| Start command | `npm run start:hostinger` |

### 3. المتغيرات البيئية (Environment Variables)

من **HOSTINGER-ENV.txt** انسخ إلى hPanel:

| المتغير | مطلوب | مثال |
|---------|--------|------|
| `AUTH_SECRET` | ✅ | (64 حرف hex من الملف) |
| `NEXT_PUBLIC_APP_URL` | ✅ | `https://yourdomain.com` |
| `NODE_ENV` | ✅ | `production` |
| `INITIAL_ADMIN_PASSWORD` | فقط بدون db.json | كلمة مرور 10+ أحرف |

**مهم:** `NEXT_PUBLIC_APP_URL` = رابط موقعك **بدون /** في النهاية.

### 4. Deploy
اضغط **Deploy** وانتظر اكتمال البناء (3–8 دقائق).

### 5. ربط الدومين
من إعدادات الموقع → **Domains** → اربط دومينك أو السابدومين.

---

## الروابط بعد النشر

| الصفحة | المسار |
|--------|--------|
| الرئيسية | `/` |
| حجز العملاء | `/book` |
| تسجيل الدخول | `/login` |
| لوحة التحكم | `/dashboard` |

---

## قاعدة البيانات

- الملف: `data/db.json`
- يُرفع مع المشروع في الـ zip
- **احفظ نسخة احتياطية** قبل كل إعادة نشر
- عند إعادة الرفع: تأكد أن `data/db.json` داخل الـ zip أو ارفعه عبر File Manager

### استعادة نسخة احتياطية
1. hPanel → **File Manager**
2. اذهب لمجلد التطبيق → `data/`
3. استبدل `db.json` بالنسخة الاحتياطية

---

## WordPress على نفس Hostinger

إذا WordPress على `yourdomain.com` والتطبيق على سابدومين:

| الموقع | الدومين |
|--------|---------|
| WordPress | `https://yourdomain.com` |
| الحجز + اللوحة | `https://book.yourdomain.com` |

`NEXT_PUBLIC_APP_URL=https://book.yourdomain.com`

زر «احجز الآن» في WordPress → `https://book.yourdomain.com/book`

---

## استكشاف الأخطاء

| المشكلة | الحل |
|---------|------|
| Build failed | تأكد Node.js **20** و `npm ci` |
| 502 / App not starting | Start command: `npm run start:hostinger` |
| تسجيل الدخول لا يعمل | تحقق من `AUTH_SECRET` في hPanel |
| روابط الحملات خاطئة | عدّل `NEXT_PUBLIC_APP_URL` وأعد Deploy |
| بيانات فارغة | تأكد من وجود `data/db.json` في السيرفر |

---

## تحديث الموقع لاحقاً

1. `npm run prepare:hostinger` (يضمّن db.json الحالي)
2. ارفع zip جديد أو اربط GitHub
3. Deploy

**تحذير:** إعادة النشر من Git **بدون** `data/db.json` قد تفقد البيانات — احتفظ بنسخة احتياطية دائماً.
