#!/usr/bin/env node
/**
 * Creates hostinger-upload.zip ready for Hostinger "Upload your files" deployment.
 * Includes data/db.json if present (your clinic data).
 */
const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");
const crypto = require("crypto");

const root = path.join(__dirname, "..");
const outZip = path.join(root, "hostinger-upload.zip");

const excludeDirs = new Set([
  "node_modules",
  ".next",
  ".git",
  ".cursor",
  "terminals",
]);

const excludeFiles = new Set([
  "hostinger-upload.zip",
  ".env",
  ".env.local",
  ".env.production",
]);

function shouldSkip(rel) {
  const parts = rel.split(/[/\\]/);
  if (parts.some((p) => excludeDirs.has(p))) return true;
  const base = parts[parts.length - 1];
  if (excludeFiles.has(base)) return true;
  if (base.endsWith(".tsbuildinfo")) return true;
  return false;
}

function collectFiles(dir, base = "") {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];
  for (const ent of entries) {
    const rel = base ? `${base}/${ent.name}` : ent.name;
    if (shouldSkip(rel)) continue;
    const full = path.join(dir, ent.name);
    if (ent.isDirectory()) {
      files.push(...collectFiles(full, rel));
    } else {
      files.push({ rel: rel.replace(/\\/g, "/"), full });
    }
  }
  return files;
}

console.log("Preparing Hostinger upload package...\n");

const files = collectFiles(root);
const staging = path.join(root, ".hostinger-staging");
if (fs.existsSync(staging)) fs.rmSync(staging, { recursive: true, force: true });
fs.mkdirSync(staging, { recursive: true });

for (const f of files) {
  const dest = path.join(staging, f.rel);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(f.full, dest);
}

const dbPath = path.join(root, "data", "db.json");
const hasDb = fs.existsSync(dbPath);
if (hasDb) {
  console.log("✓ Including data/db.json (clinic database)");
} else {
  console.log("⚠ No data/db.json — Hostinger will create empty DB on first run.");
  console.log("  Set INITIAL_ADMIN_PASSWORD in Hostinger env vars.");
}

const secret = crypto.randomBytes(32).toString("hex");
const envGuide = `# Hostinger — Environment Variables (hPanel → Node.js App → Environment)
# Copy each line to Hostinger settings (NOT into the zip file)

AUTH_SECRET=${secret}
NEXT_PUBLIC_APP_URL=https://YOUR-DOMAIN.com
NODE_ENV=production
${hasDb ? "# Database included in upload — INITIAL_ADMIN_PASSWORD not needed" : "INITIAL_ADMIN_PASSWORD=YourStrongPassword123!"}

# Hostinger build settings:
# Install:  npm ci
# Build:    npm run build
# Start:    npm run start:hostinger
# Node.js:  20
`;

fs.writeFileSync(path.join(staging, "HOSTINGER-ENV.txt"), envGuide, "utf-8");
fs.writeFileSync(path.join(root, "HOSTINGER-ENV.txt"), envGuide, "utf-8");

console.log("\n✓ Generated HOSTINGER-ENV.txt with AUTH_SECRET (save it securely)\n");

if (fs.existsSync(outZip)) fs.unlinkSync(outZip);

const isWin = process.platform === "win32";
try {
  if (isWin) {
    execSync(
      `powershell -NoProfile -Command "Compress-Archive -Path '${staging}\\*' -DestinationPath '${outZip}' -Force"`,
      { stdio: "inherit", cwd: root }
    );
  } else {
    execSync(`cd "${staging}" && zip -r "${outZip}" .`, { stdio: "inherit" });
  }
  const sizeMb = (fs.statSync(outZip).size / 1024 / 1024).toFixed(2);
  console.log(`\n✓ Created: hostinger-upload.zip (${sizeMb} MB)`);
  console.log("  Upload this file in Hostinger → Add Website → Node.js → Upload\n");
} catch (e) {
  console.error("Could not create zip automatically. Staging folder:", staging);
  console.error(e.message);
  process.exit(1);
} finally {
  fs.rmSync(staging, { recursive: true, force: true });
}
